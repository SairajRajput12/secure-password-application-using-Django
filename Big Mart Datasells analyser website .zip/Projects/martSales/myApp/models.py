from django.db import models

# class excelFile(models.Model):
#     file = models.FileField(upload_to="excel")

    